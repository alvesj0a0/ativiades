public class Banco {
    public static void main(String[] args) {
        ContaBancaria conta1 = new ContaBancaria();
        conta1.numeroConta = "0001";
        conta1.titular = "Neymar Jr";
        conta1.saldo = 100000.0;

        ContaBancaria conta2 = new ContaBancaria();
        conta2.numeroConta = "0002";
        conta2.titular = "Helder Barbalho";
        conta2.saldo = 52654.0;

        System.out.println("Conta 1...");
        System.out.println("----------------------------------------");
        conta1.consultarSaldo();
        conta1.depositar(200.0);
        conta1.sacar(150.0);
        conta1.consultarSaldo();

        System.out.println("----------------------------------------");
        System.out.println("\nConta 2...");
        System.out.println("----------------------------------------");
        conta2.consultarSaldo();
        conta2.depositar(300.0);
        conta2.sacar(1000.0); // teste com saldo insuficiente
        conta2.consultarSaldo();
    }
}
