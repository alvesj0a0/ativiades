
public class ProjetoCarro {
    public static void main(String[] args) {
        Carro carro1 = new Carro();
        carro1.marca = "Wolkswagen";
        carro1.modelo = "Gol";
        carro1.ano = 1990;

        Carro carro2 = new Carro();
        carro2.marca = "Fiat";
        carro2.modelo = "147";
        carro2.ano = 1976;

        carro2.marca = "Mitsubishi";
        carro2.modelo = "pajero";
        carro2.ano = 2020;

        System.out.println("Carro 2 (atualizado)...");
        carro2.mostrarInfor();

        System.out.println("--------------------------------");
        System.out.println("Status do carro 1...");
        carro1.mostrarInfor();
        carro1.ligar();

        carro2.ligar();
    }
}
