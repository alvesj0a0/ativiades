public class ProjetoAluno {
    public static void main(String[] args) {

        Aluno aluno1 = new Aluno();
        aluno1.nome = "Samara Souza";
        aluno1.matricula = 101;
        aluno1.notAv1 = 10.0;
        aluno1.notAv2 = 5.0;

        Aluno aluno2 = new Aluno();
        aluno2.nome = "João Alves";
        aluno2.matricula = 102;
        aluno2.notAv1 = 10.0;
        aluno2.notAv2 = 8.0;

        aluno1.notAv1 = 4.0;

        System.out.println("Dados atualizados do(a) aluno(a) 1:...");
        aluno1.mostrarDados();

        aluno1.verifAprovacao();

        System.out.println("\nDados do(a) aluno(a) 2:...");
        aluno2.mostrarDados();
        aluno2.verifAprovacao();
    }
}
