
public class Aluno {
    String nome;
    int matricula;
    double notAv1;
    double notAv2;

    void mostrarDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Matrícula: " + matricula);
        System.out.println("Nota AV1: " + notAv1);
        System.out.println("Nota AV2: " + notAv2);
    }

    double calMedia() {
        return (notAv1 + notAv2) / 2;
    }

    void verifAprovacao() {
        double media = calMedia();
        System.out.println("Média: " + media);
        if (media >= 7.0) {
            System.out.println("Aluno aprovado!");
        } else if (media >= 4.0) {
            System.out.println("Vai para Prova final!");
        } else {
            System.out.println("Aluno reprovado!");
        }
    }
}
