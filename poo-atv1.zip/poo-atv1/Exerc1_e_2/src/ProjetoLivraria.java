public class ProjetoLivraria {
    public static void main(String args[]) {
        Livro obj1; // declaração de variavel
        Livraria obj2;

        obj1 = new Livro(); // instanciação do objeto
        obj2 = new Livraria();

        obj2.nome = "LIvraria do Zé";
        obj2.cnpj = "12.345.678/0001-99";
        obj2.endereco = "Rua aleatória, 123, Centro, Belém - PA";

        // intanciando atributos do objeto
        obj1.titulo = "The little prince";
        obj1.numeroPaginas = 96;
        obj1.anoPublicacao = 1943;
        obj1.preco = "R$ 30,00";

        // intanciação dos objetos omitidos
        System.out.println("-----------------------------------------------------");
        System.out.println("informacões do livro...");
        System.out.println("-----------------------------------------------------");

        System.out.println("Titulo: " + obj1.titulo);
        System.out.println("Numero de pág.: " + obj1.numeroPaginas);
        System.out.println("Ano de pub.: " + obj1.anoPublicacao);
        System.out.println("Preço: " + obj1.preco);

        System.out.println("-----------------------------------------------------");
        System.out.println("informacões da livraria...");
        System.out.println("-----------------------------------------------------");
        System.out.println("Nome: " + obj2.nome);
        System.out.println("CNPJ: " + obj2.cnpj);
        System.out.println("Endereço: " + obj2.endereco);
        System.out.println("-----------------------------------------------------");

    }

}
