public class Livro {
    String titulo;
    int numeroPaginas;
    int anoPublicacao;
    String preco;

    void cadastrar() {
        System.out.println("Cadastrando banco de dados...");
    }

    double calcFrete(String cep) {
        System.out.println("Calculando frete para o CEP" + cep);
        double valorFrete = 20.00;
        return valorFrete;
    }

    void vender() {
        System.out.println("Vendendo livro por R$ %,2f, preco");
    }

    String trocar() {
        return "Livro tracado!";
    }

}
