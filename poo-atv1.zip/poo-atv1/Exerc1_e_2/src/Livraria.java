public class Livraria {
    String nome;
    String cnpj;
    String endereco;

    void cadastrar() {
        System.out.println("Cadastrando livraria...");

    }

    void informacoes() {
        System.out.println("Nome: " + nome);
        System.out.println("CNPJ: " + cnpj);
        System.out.println("Endereço: " + endereco);
    }

}
